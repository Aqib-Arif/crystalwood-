<?php
include 'admin/include/config.php';
include 'admin/include/functions.php';
?>

<!DOCTYPE html>
<HTML lang="en">
<head>
<title>Crystal Wood</title>
	<meta http-equiv="Content-Language" 	content="en-us" />
	<meta name="language" 					content="en-us" />
	<meta http-equiv="Content-Type" 		content="text/html; charset=UTF-8" />
	<meta charset="UTF-8">
	<meta name="viewport" 					content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<meta name="classification" 			content="religion content" />
	<meta name="distribution" 				content="Global" />
	<meta name="rating" 					content="General" />
	<meta name="robots" 					content="" />
	<meta name="revisit-after" 				content="" />
	<meta name="creator" 					content="Muhammad Manamil , Aqib Ali" />
	<meta name="publisher" 					content="" />
	<meta name="description" 				content="" />
	<meta name="keywords" 					content="">

	
	<link rel="shortcut icon" href="images/Fav_Icon.svg" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/customize.css">	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,200;0,500;1,200&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/OwlCarousel/docs/assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="css/OwlCarousel/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
</head>
<body>