<section class="topbar pt-2  pb-md-2 pb-0">  
    <div class="container-fluid  border-bottom">
      <div class="row">
        <div class="col-md-6 col-12 text-md-left text-center">
          <p class="text-dark mb-md-2 mb-0 small">Default welcome msg!</p>
        </div>
        <div class="col-md-6 d-md-block d-none text-right">
            <a href="register" class="d-inline-block  text-dark">Register</a>
            <span class="px-2 text-dark">|</span>
            <a href="login" class="d-inline-block  text-dark">Login</a>
        </div>
      </div>
    </div>
</section>
<section class="nav py-md-3 py-1">
  <div class="container-fluid">
     <div class="row align-items-center">
        <div class="col-lg-2 col-lg-2 col-12 ">
           <div class="row align-items-center">
              <div class="col-3 d-lg-none text-left">
                <span type="button" class="mobile-menu"><img src="images/bar.png" width="20" alt=""></span> 
              </div>
              <div class="col-6 d-lg-12 abc text-lg-left text-center  pl-md-5 pl-0">
                <a href="index"  class="d-inline-block">
                  <img src="<?php echo $url_domain;?>/images/crystalwood_logo.svg"   width="180" alt="">
                </a>
              </div>
              <div class="col-3  d-lg-none text-right">
                <a href="login" class="d-inline-block pr-lg-3 pr-2" ><i class="fa fa-user" aria-hidden="true"></i></a>
                <a href="" class="d-inline-block " ><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
              </div>
           </div>
        </div>
        <div class="col-xl-8 col-lg-10 col-12 mt-lg-0 mt-3">
          <div class="row align-items-center">
            <div class="col-xl-4 col-lg-5 d-lg-block d-none">
                <a href="" class="d-inline-block small">Kitchens</a>
                <a href="" class="d-inline-block px-lg-3 px-1">Doors</a>
                <a href="" class="d-inline-block">Bedrooms</a> 
            </div>
            <div class="col-xl-8 col-lg-7 col-12">
              <div class="input-group border rounded">
                  <input type="text" class="form-control border-0" placeholder="Search" aria-label="Recipient's username" aria-describedby="basic-addon2">
                  <div class="input-group-append bg-light">
                    <span class="btn bg-white" id="basic-addon2"><i class="fa fa-search"></i></span>
                  </div>
              </div>
            </div>
          </div>  
        </div>
        <div class="col-xl-2 d-xl-block d-none text-right">
          <a href="login" class="d-inline-block pr-lg-3 pr-2" ><i class="fa fa-user" aria-hidden="true"></i></a>
          <a href="" class="d-inline-block pr-4 " ><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
        </div>
     </div>
  </div>
</section>
<!-- 
  <div class="container-fluid  pl-md-5 pl-0 nav-res">
     <a href="bedroom" class="d-lg-inline-block d-block small text-dark ">Bedroom<i class="fa fa-caret-down pl-2" aria-hidden="true"></i> </a>
     <a href="" class="d-lg-inline-block d-block small text-dark pl-4 ">Living <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Study <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4 ">Kids <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Dining <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Decor <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Office <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Kitchens <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Doors <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Wardrobes <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <a href="" class="d-lg-inline-block d-block  text-dark pl-4">Trending <i class="fa fa-caret-down pl-2" aria-hidden="true"></i></a>
     <div class="right d-lg-none text-left mobile-menu">
        <i class="fa fa-times fa-lg text-danger p-2"></i>
     </div>
    </div>
 -->
 
<section class="nav-bottom"> 
  <ul class="main-nav mb-0 pl-md-4 pl-0 nav-res">
      <li><a href="bedroom">Bedroom <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
       <li>
          <a class="mega-menu">Living <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a>
          <div class="sub-menu-block">
              <div class="row">
                  <div class="col-md-3">
                    <h6>SOFAS</h6>
                    <ul class="sub-menu-lists">
                          <li><a>Sofa Set</a></li>
                          <li><a>1 Seater Sofa</a></li>
                          <li><a>2 Seater Sofa</a></li>
                          <li><a>3 Seater Sofa</a></li>
                          <li><a>L Shaped Sofa</a></li>
                      </ul>           
                  </div>
                  <div class="col-md-3">
                      <h6>RECLINERS</h6>
                      <ul class="sub-menu-lists">
                          <li><a>Power Lift</a></li>
                          <li><a>Power</a></li>
                          <li><a>Mannul</a></li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <h6>TABLES</h6>
                      <ul class="sub-menu-lists">
                          <li><a>Cofee Table</a></li>
                          <li><a>Center Table</a></li>
                          <li><a>Side End Table</a></li>
                          <li><a>Neasted Table</a></li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                      <img src="images/wedding.jpg" class="w-100" alt="">
                     </div>
                    <div class="col-md-3">
                      <h6>OUTDOOR FURNITURE</h6>
                      <ul class="sub-menu-lists">
                          <li><a>Outdoor Chair</a></li>
                          <li><a>Outdoor Table</a></li>
                          <li><a>Swings</a></li>
                      </ul>
                    </div>    
              </div>
          </div>
      </li>
      <li><a>Study <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li> 
        <li>
            <a class="mega-menu">Kids <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a>
            <div class="sub-menu-block">
                <div class="row">
                    <div class="col-md-3">
                        <h6>KIDS BEDS</h6>
                        <ul class="sub-menu-lists">
                          <li><a>Bed Sets</a></li>
                          <li><a>Single Beds</a></li>
                          <li><a>Bunk Beds</a></li>
                          <li><a>Sliding Beds</a></li>
                        </ul>           
                    </div>
                    <div class="col-md-3">
                        <h6>STORAGE</h6>
                        <ul class="sub-menu-lists">
                          <li><a>Bedside Tables</a></li>
                          <li><a>Dressing Tables</a></li>
                          <li><a>Kids Wardrobe</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h6>Table</h6>
                        <ul class="sub-menu-lists">
                          <li><a>TABLES & DESKS</a></li>
                          <li><a>Kids Study Tables</a></li>
                          <li><a>KIDS SEATING & CHAIRS</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                      <img src="images/wedding.jpg" class="w-100" alt="">
                    </div>
                </div> 
            </div>
        </li>
        <li><a>Dining <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Decor <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Office <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Kitchens <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Doors <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Wardrobes <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <li><a>Trending <i class="fa fa-caret-down pl-1" aria-hidden="true"></i></a></li>
        <div class="right d-lg-none text-left mobile-menu">
          <i class="fa fa-times fa-lg text-danger p-2"></i>
       </div>
  </ul> 
</section>