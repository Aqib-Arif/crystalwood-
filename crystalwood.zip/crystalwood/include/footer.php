<?php

   if(isset($_POST['save'])){

    $email			= $_POST['email'];

	if(empty($email))
		$error[] = "Please type post email == info-circle == danger";

	if(empty($error)){
		$insert = insert_and_update_data('insert', 'email', array('email'=> $email));
	}
}
?>
<footer class="pt-5 bg-light footer">
	<div class="container">
		<div class="row">
        <div class="col-md-4 mb-2">
            <a href="index"  class="d-block mb-3">
                <img src="<?php echo $url_domain;?>/images/crystalwood_logo.svg"  width="180" alt="">
            </a>
            <a href=""  class="d-block"><i class="fa fa-home mr-3 mb-3" aria-hidden="true"></i> 82 Valley Farms Court Grovetown </a> 
            <a href="tel:+92 323 2868866"  class="d-block"><i class="fa fa-phone mr-3 mb-3 " aria-hidden="true"></i> +92 323 2868866</a> 
            <a href="mailto:info@crystalwood.pk"  class="d-block"><i class="fa fa-envelope-o mb-3 mr-3" aria-hidden="true"></i>info@crystalwood.pk</a> 
            <a href=""  class="d-block"><i class="fa fa-clock-o mr-3 mb-4" aria-hidden="true"></i> Mon - Sat : 8 AM - 5 PM</a> 
           
        </div>
        <div class="col-md-4 mb-3">
           <h5 class="mb-4 font-weight-bold">INFORMATION</h5>
           <a href="about" class="d-block mb-3">About Crystalwood</a>
           <a href="contact" class="d-block mb-3">Contact Us</a>
           <a href="blog" class="d-block mb-3">Blog</a>
           <a href="term" class="d-block mb-3">Terms of Use</a>
           <a href="privacy" class="d-block mb-3">Privacy Policy</a>
        </div>
		  	<div class="col-md-4 mb-3">
            <h5 class="mb-4 font-weight-bold">Newsletter</h5>
            <p>Subscribe to our Newsletter</p>
            <form action="" method="post">
              <div class="input-group mb-3">
                  <input type="text" class="form-control" name="email" placeholder="Type Your E-mail" aria-label="Recipient's username" aria-describedby="basic-addon2">
                  <div class="input-group-append">
                      <button class="btn border" name="save"><i class="fa fa-envelope-o" aria-hidden="true"></i></button>
                  </div> 
              </div>
            </form>
           <a href=""><i class="fa fa-facebook ml-md-2 ml-0"></i></a>
           <a href=""><i class="fa fa-instagram ml-3"></i></a>
           <a href="" ><i class="fa fa-youtube ml-3"></i></a>
        </div>
		</div>
	</div>
</footer>
<section class="footer-bottom border-top py-2 bg-light">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-center">
				  <span class="small"><a>Copyright 2022 &copy;  Crystalwood | <a href="https://snowdreamstudios.com/" target="_blank">Design By Snow Dream Studios</a></a> </span>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript" src="js/jquery-3.2.1.slim.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/customize.js"></script>
<script src="css/OwlCarousel/docs/assets/owlcarousel/owl.carousel.min.js"></script> 
<script type="text/javascript" src="js/jquery.izoomify.js" ></script>

</body>
</html>