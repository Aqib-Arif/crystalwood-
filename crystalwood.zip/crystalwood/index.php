<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<style>
.card img{
	position: relative;
}
.card .playbutton{
	position: absolute; 
	top: 63%;
	left: 90%;
    transform: translate(-50%, -50%);
    color:#A3886B;
	font-size:30px;
}	
.playbutton{
	display: none;	
}
.upload .card:hover .playbutton{display: inline-flex}
</style>
<section class="py-2">
	<div class="owl-carousel banner">
		<div class="items" style="background-image:url(./images/banner1.jpg) ;">
		     <div class="container-fluid h-100">
				<div class="row h-100 align-items-center">
				    <div class="col-md-6"></div>
					<div class="col-md-6  heading">
						<h2 class="mb-2 font-weight-bold ">A good modern chair says a lot about its owner</h2>
						<p class="mb-md-4">Add more comfort to your life with our chairs made with high-quality materials ensuring durability over time. Explore our rich collection of chairs for your space.</p>
						<button href="" class="btn btn-outline-light px-5 py-2 " >Buy Now</button>	
					</div>
				</div>
			  </div>
		 </div>
		 <div class="items"  style="background-image:url(./images/banner2.jpg) ;">
				<div class="container-fluid h-100 ">
					<div class="row  h-100 align-items-center">
						<div class="col-md-6"></div>
						<div class="col-md-6  heading">
							<h2 class="mb-2 font-weight-bold ">Leave an enduring impression with our beautiful main doors</h2>
							<p class="mb-md-4">Our high-quality doors are known for their durability, aesthetics, and functionality. Leave a great first impression while welcoming people into your home or office with a beautiful main door.</p>
							<button href="" class="btn btn-outline-light px-5 py-2 " >Buy Now</button>	
						</div>
					</div>
				</div>
		  </div>
		  <div class="items"  style="background-image:url(./images/banner3.jpg) ;">
			<div class="container-fluid h-100 ">
				<div class="row  h-100 align-items-center">
					<div class="col-md-6 ml-md-5 ml-0 heading">
						<h2 class="mb-2 font-weight-bold ">Crystal wood offers modern kitchen designs with customisation</h2>
						<p class="mb-md-4">Crystal wood gives attention to every small detail to provide you with the kitchen of your dreams that’s aesthetic, enjoyable, and, most importantly, convenient. </p>
						<button href="" class="btn btn-outline-light px-5 py-2 " >Buy Now</button>
					</div>
				</div>
			</div>
	  </div>
 	</div>
</section>
<section class="py-5 cara mb-md-4">
	<div class="container text-center">
		<h2>Shop By Category</h2>
		<div class="owl-carousel pakistan py-3">
			<div class="item">
			   <a href="" class="card text-center w-100">
					<img src="<?php echo $url_domain;?>/images/sofa.svg" height="100px" alt="">
					 <p >Chair</p>
			   </a> 
			</div>
			<div class="item">
				<a href="" class="card  text-center">
					<img src="<?php echo $url_domain;?>/images/safealmari.svg" height="100px" alt="">
					 <p>Safe Almari</p>
				</a> 
			</div>
			<div class="item">
				<a href="" class="card  text-center">
					<img src="<?php echo $url_domain;?>/images/draz.svg" height="100px" alt="">
					<p>Daraz</p>
				</a> 
			</div>
			<div class="item">
				<a href="" class="card  text-center">
					<img src="<?php echo $url_domain;?>/images/lamb.svg" height="100px" alt="">
					<p>Lamp</p>
				</a> 
			</div>
			<div class="item">
				<a href="" class="card text-center">
					<img src="<?php echo $url_domain;?>/images/bookshelves.svg" height="100px" alt="">
					<p>Bookshelves</p>
				</a> 
			</div>
			<div class="item">
				<a href="" class="card  text-center">
					<img src="<?php echo $url_domain;?>/images/study-table.svg" height="100px" alt="">
					<p>Study Table</p>
				</a> 
			</div>
		</div>
	</div>	
</section>
<section class="upload">
	<div class="container">
		<h2 class="text-center mb-4">Recently Uploaded</h2>
		<div class="row">
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar"></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons">
					 	 <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="addtocart" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					  </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar"></i>
					  <i class="fa fa-star colorstar"></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons ">
					    <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="addtocart" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
						
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					   <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					   </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar" ></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons">
					 	 <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="" >
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar "></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons ">
					     <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						  <a href="addtocart" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="py-4 upload ">
     <div class="container">
		<div class="row">
		<h6>Best Seller Item</h6>
		</div>
	 </div>
	<div class="container border-top border-dark">
		<div class="row">
			<div class="col-md-4  py-3 border-right abcd border-dark">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="" >
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar"></i>
					  <i class="fa fa-star colorstar"></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons pt-2">
					       <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						   </a>
						   <a href="addtocart" class=" justify-content-center text-center">
							   <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						   </a>
				      </div>
					</div>
				</div>
			</div>
			<div class="col-md-4 border-right border-dark">
				<div class="row">
					<div class="col-md-12 border-bottom border-dark ">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class="small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>	
								   </div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12 border-bottom border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>
										
								    </div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12  border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>
										
								    </div>
								</div>
							</div>		
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4 border-right border-dark">
				<div class="row">
					<div class="col-md-12 border-bottom border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>
										
								    </div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12 border-bottom border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>
										
								    </div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12  border-dark">
						<div class="card border-0  py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons pt-2">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>	
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>	
								    </div>
								</div>
							</div>		
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="upload">
	<div class="container">
		<h2 class="text-center mb-4">Lorem Ipsum</h2>
		<div class="row">
			<div class="col-md-3  col-6">
				<div class="card border-0">
					<div>
					  <img class=" w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar"></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons">
					 	 <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="addtocart" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					  </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar"></i>
					  <i class="fa fa-star colorstar"></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons ">
					    <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="addtocart" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
						
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="">
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar" ></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons">
					 	 <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 " src="<?php echo $url_domain;?>/images/door.jpg" alt="" >
					  <a href="" >
					      <i class="fa fa-play-circle  playbutton" aria-hidden="true" style=""></i>
					  </a>
					  <i class="fa fa-star  text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star text-warning"></i>
					  <i class="fa fa-star colorstar "></i>
					  <i class="fa fa-star colorstar" ></i>
					  <p class="small mb-2">Hagen Lounge Chair Classic</p>
					  <p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
					  <div class="icons ">
					     <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						  <a href="addtocart" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="upload">
	<div class="container">
		<div class="row">
		<h6 class="">Best Seller Item</h6>
		</div>
	</div>
   <div class="container border-top border-dark">
	   <div class="row">
		   <div class="col-md-4 border-right border-dark">
			  <div class="row">
				<div class="col-md-12 border-bottom border-dark">
					<div class="card border-0 py-3">
						<div class="d-flex  text-md-left   mb-md-3 mb-1">
							<img src="<?php echo $url_domain;?>/images/door2.jpg" width="125" height="100" class="pr-3">
							<div>
								<i class="fa fa-star  text-warning  pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star pt-2  colorstar" ></i>
								<i class="fa fa-star pt-2 colorstar" ></i>
								<p class=" small mb-2">Hagen Lounge Chair Classic</p>
								<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
								<div class="icons ">
									<a href="productlist" class="justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
									</a>
									<a href="addtocart" class=" justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
									</a>		
								</div>
							</div>
						</div>		
					</div>
				</div>
				<div class="col-md-12 border-bottom border-dark">
					<div class="card border-0  py-3">
						<div class="d-flex  text-md-left   mb-md-3 mb-1">
							<img src="<?php echo $url_domain;?>/images/door2.jpg" width="125" height="100" class="pr-3">
							<div>
								<i class="fa fa-star  text-warning  pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star pt-2  colorstar" ></i>
								<i class="fa fa-star pt-2 colorstar" ></i>
								<p class=" small mb-0">Hagen Lounge Chair Classic</p>
								<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
								<div class="icons ">
									<a href="productlist" class="justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
									</a>
									<a href="addtocart" class=" justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
									</a>		
								</div>
							</div>
						</div>		
					</div>
				</div>
				<div class="col-md-12   border-dark">
					<div class="card border-0  py-3">
						<div class="d-flex   text-md-left   mb-md-3 mb-1">
							<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
							<div>
								<i class="fa fa-star  text-warning  pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star text-warning pt-2"></i>
								<i class="fa fa-star pt-2  colorstar"></i>
								<i class="fa fa-star pt-2 colorstar"></i>
								<p class=" small mb-0">Hagen Lounge Chair Classic</p>
								<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
								<div class="icons ">
									<a href="productlist" class="justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
									</a>
									<a href="addtocart" class=" justify-content-center text-center">
										<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
									</a>		
								</div>
							</div>
						</div>		
					</div>
				</div>
			  </div>
		   </div>
		   <div class="col-md-4 border-right border-dark">
			   <div class="row">
				 <div class="col-md-12 border-bottom border-dark">
						<div class="card border-0  py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door2.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar"></i>
									<i class="fa fa-star pt-2 colorstar"></i>
									<p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
				  </div>
				  <div class="col-md-12 border-bottom border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
									<p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
				  </div>
				  <div class="col-md-12  border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door2.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
									<p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
				   </div>
			   </div>
		   </div>
		   <div class="col-md-4 border-right border-dark">
			   <div class="row">
					<div class="col-md-12 border-bottom border-dark">
						<div class="card border-0 py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
									<p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12 border-bottom border-dark">
						<div class="card border-0  py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
					</div>
					<div class="col-md-12 border-dark">
						<div class="card border-0  py-3">
							<div class="d-flex  text-md-left   mb-md-3 mb-1">
								<img src="<?php echo $url_domain;?>/images/door2.jpg" width="125" height="100" class="pr-3">
								<div>
									<i class="fa fa-star  text-warning  pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star text-warning pt-2"></i>
									<i class="fa fa-star pt-2  colorstar" ></i>
									<i class="fa fa-star pt-2 colorstar" ></i>
								    <p class=" small mb-0">Hagen Lounge Chair Classic</p>
									<p class="small text">$30.00 <s class="ml-2">$35.00</s></p>
									<div class="icons ">
										<a href="productlist" class="justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
										</a>
										<a href="addtocart" class=" justify-content-center text-center">
											<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
										</a>		
									</div>
								</div>
							</div>		
						</div>
					</div>
			   </div>
		   </div>
	   </div>
   </div>
</section>
<section class="blog py-5">
	<div class="container">
		<h2 class="text-center mb-4">OUR BLOGS</h2>
		<div class="row">
			<div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
			<div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0  small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
			<div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
			<div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
 include 'include/footer.php';
?>
<script>
	$('.pakistan').owlCarousel({
    loop:true,
    margin:40,
    nav:false,
    dots: false,
	autoplay:true,
	autoplayTimeout:2000,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:4
        },
        
    }
  });
  $('.banner').owlCarousel({    
     lazyLoad:true,     
     rtl:false,     
     loop:true,     
     video:true,     
     center:true,     
     autoplay:true,     
     autoplayTimeout:5000,     
     autoplayHoverPause:false,     
     stagePadding: 0,     
     items:3,          
     // slideBy: 1,     
     // animateOut: 'fadeOut',     
     //     animateIn: 'fadeIn',     
     //     slideSpeed: 30000,     //    
      paginationSpeed: 30000,     
      responsive:{        
        0:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,         
        },         
        576:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,           
        },         
        768:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,     
        },         
        992:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,          
        },        
        1200:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,         
        }     
    } 
});
</script>