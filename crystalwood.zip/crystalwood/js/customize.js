//scroll down to fixed top navbar
$(document).ready(function(){
	   $(window).bind('scroll', function() {
			 if ($(window).scrollTop() > 500) {
				 $('.course-nav').addClass('fixed-top');
			 }
			 else {
				 $('.course-nav').removeClass('fixed-top');
			 }
		});
});



//navigation bar
$(document).ready(function() {
	$('.mobile-menu').click(function() {
		$('.nav-res').toggleClass('show');
		$('.right').toggleClass('show');
	});
	
});
