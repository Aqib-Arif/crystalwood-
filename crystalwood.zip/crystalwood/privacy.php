<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="py-5">
  <div class="container ">
        <h4 class="mb-4">Privacy Policy</h4>
        <p>Crystal wood takes privacy very seriously and sets the highest standards to maintain privacy. We appreciate that you guys trust us with your personal information, and we do our best to preserve it. Keep reading to understand our privacy policy.</p>
        <p class="mb-5">Please note that we keep changing our privacy policy from time to time, so make sure that you review the privacy policy periodically. This privacy policy doesn’t apply to any third parties you may interact with on our website. </p>
        <h4 class="mb-4">Customer Information Crystal Wood Collects:</h4>
        <li class="mb-3">Customer contact details like phone number, customer’s name, e-mail address, and shipping address.</li>
        <li class="mb-3">Your banking or transaction details include the cardholder's credit card details. We do transactions via banks and Cash on Delivery (COD). Banks ensure the highest standards of privacy for your private information.</li>
        <li class="mb-3">Your previous orders and transactions details, pricing details, date of purchase, payment history etc.</li>
        <li class="mb-3">If you fill out any online surveys on our third-party sites (optional), we’ll collect information like your age, gender, and income from those surveys.</li>
        <li class="mb-3">Our website uses cookies: Cookies Cookies is a piece of data stored by a website within a browser that enables the browser to remember information specific to a given user, such as clicking particular buttons, logging in, or having read certain pages on our site. All leading websites such as Amazon, Yahoo, Google and Facebook use cookies. You can set your browser to notify you when you are sent a cookie, and you can decide whether or not to accept it.</li>
        <li class="mb-5">Information of your navigation with our site, your IP address which also includes your location, browser type, browser location, date and time etc.</li>
        <h4 class="mb-4">How do we utilize this information?</h4>
        <p class="mb-4"><strong>Note:</strong>We collect user information to improve our services and provide our customers with the best possible experience; we don’t sell our customer information to third parties.</p>
        <p>Continue reading to know how we use our customer information.</p>
        <li class="mb-3">Customer information will be shared with the affiliates and partners who are also involved in delivering the service. </li>
        <li class="mb-3">We use some of the customer information to improve our services and to provide you with the best experience depending upon your preferences        </li>
        <li class="mb-3">We use your information to let you know about the latest deals, offers, your shipping status, and other advertisement content. </li>
        <li class="mb-3">Cookies will be used to know the latest articles you have viewed to provide the best possible items.</li>
        <li class="mb-3">Traffic sources, IP addresses, and OS information will be used to navigate the site's overall performance, user engagement, and the time spent by the users on the site</li>
        <li class="mb-3">To comply with illegal activities, fraud, troubleshooting problems, and other disputes, the company will expose your personal data to cooperate with law enforcement to protect the honour of the company and other users’ data</li>
        <li class="mb-3">Please contact us via email if you want us to remove your private information.</li>
        <li class="mb-3">If you have any queries regarding our privacy policy, please contact us via email, and we’ll get back to you.</li>
  </div>
</section>
<?php
 include 'include/footer.php';
?>