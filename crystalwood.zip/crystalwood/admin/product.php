<?php
  require_once 'include/head.php';
  session('admin_id');
?>
<div id="accordion2" class="">
	<div class="row align-items-center pt-3 sale-heading">
		<div class="col-6">
			<h5 class="font-dark">Product</h5>
		</div>
		<div class="col-6 text-right">
			<button class="btn btn-primary px-2 mb-3" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				<i class="fa fa-search"></i>
			</button>
			<a href="add-product.php" class="btn btn-primary px-2 mb-3"><i class="fa fa-plus"></i></a>
		</div>
		<div class="col-md-12">
			<div id="collapseOne" class="collapse <?php if(!empty($searchText)){echo 'show';}?>" aria-labelledby="headingOne" data-parent="#accordion2">
				<div class="card card-body border-0 shadow mb-3">
					<h6 class="font-weight-bold">Search</h6>
					<form method="get"  class="align-items-end row">
						<div class="col-md-9 mb-md-0 mb-2">
							<input type="text" value="<?php echo $searchText;?>" name="search" class="form-control bg-light">
						</div>
						<div class="col-md-3">
							<input type="submit" value="Search Now" class="btn btn-sm btn-primary btn-block">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card card-body border-0 shadow">
			<div class="table-responsive">

			</div>
		</div>
	</div>
</div>
		
<?php
    require_once 'include/footer.php';
?>