<?php 	
  require_once 'include/head.php';	

  session('admin_id');
  if(isset($_POST['addpost'])){
	$title			= cleanStr($_POST['title']);
	$description	= cleanStr($_POST['description']);
	
	$slug =  str_replace(" ", "-", strtolower($title));

	if(empty($title))
		$error[] = "Please type post title == info-circle == danger";
	
	if(empty($description))
		$error[] = "Please type post description == info-circle == danger";
	
	if(empty($error)){
		$insert = insert_and_update_data('insert', 'blog', array('slug'=>$slug,'title'=> $title,'description'=> $description),'', 'image', 'images/blogs', 'png,jpg,jpeg', '800','300');
		if($insert == true){
			$error[] = 'Post added successfully';
		}
	}
}
?>
<div class="row align-items-center pt-3">
	<div class="col-6 mb-3">
		<h5 class="font-dark">Add Post</h5>
	</div>
</div>
<form method="post" action="" enctype="multipart/form-data" >
	<div class="row">
		<div class="col-md-12">
			<div class="card card-body shadow border-0 mb-3">
				<div class="row">
					<div class="col-lg-9 mb-3">
						<div class="row">
							<div class="col-md-12">
								<label class="label d-block mb-0">
									<input type="text" value="<?php  echo $title; ?>" name="title"  placeholder="Title" class="form-control p-2 mb-3">
									<span class="<?php if(!empty($title)){echo 'd-block';}else{echo' d-none';} ?>">Title</span>
								</label>
							</div>
							<div class="col-md-12">
								<textarea name="description" id="editor" placeholder="Description" class="form-control p-2 mb-3"><?php echo $description;?></textarea>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="card card-body bg-light pb-0 mb-3">
							<h6><i class="fa fa-image pr-2"></i>Select Image</h6>
							<div class="agent-img mb-2 text-center border">
								<img id="blah" src="../images/demo.png" width="100%">
							</div>
							<input type="file" id="imgInp" name="image" class="form-control p-2 mb-3 bg-white">		
						</div>
					</div>
					<div class="col-12 text-right">
						<input type="submit" value="Add Post" name="addpost" class="btn btn-sm btn-primary px-3">
					</div>
				</div>
			</div>
		</div>
	</div>
<form>
 <script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'editor' );



$('.form-control').on('blur', function(){
	var emptycheck = $(this).val();
	if(emptycheck.trim() == '' ){
		$(this).next('span').removeClass('d-inline-block').addClass('d-none');
		$(this).attr("class", "border form-control p-2 mb-3");
		var text =	$(this).next('span').text();
		$(this).attr("placeholder",text);
		
	}else{
		$(this).attr("class", "border form-control p-2 mb-3");
		$(this).next('span').removeClass('text-primary').addClass('d-inline-block span-color');
	}
	
})
.on('focus', function(){
	$(this).attr("placeholder", "");
	$(this).attr("class", "border border-primary form-control p-2 mb-3");
	
	$(this).next('span').removeClass('d-none').addClass('d-inline-block text-primary');
});


//image show 
function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function (e) {
			$('#blah').attr('src', e.target.result);	
		}
		reader.readAsDataURL(input.files[0]);
	}
}

$("#imgInp").change(function(){
	readURL(this);
});

//select only one checkbox
 $('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});

</script>
<?php
	require_once 'include/footer.php';
?>