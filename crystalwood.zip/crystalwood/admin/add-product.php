<?php 	
  require_once 'include/head.php';	
  session('admin_id');
?>
<div class="row align-items-center pt-3">
	<div class="col-6 mb-3">
		<h5 class="font-dark">Add Product</h5>
	</div>
</div>
<form method="post" action="" enctype="multipart/form-data" autocomplete="off">
	<div class="row">
		<div class="col-md-12">
			<div class="card card-body shadow border-0 mb-3">
				<div class="row">
					<div class="col-lg-9 mb-3">
						<div class="row">
							<div class="col-md-12">
								<label class="label d-block mb-0">
									<input type="text" value="<?php  echo $title; ?>" name="title"  placeholder="Title" class="form-control p-2 mb-3">
									<span class="<?php if(!empty($title)){echo 'd-block';}else{echo' d-none';} ?>">Title</span>
								</label>
							</div>
                            <div class="col-md-12">
								<label class="label d-block mb-0">
									<input type="number" value="<?php  echo $Price; ?>" name="price"  placeholder="Price" class="form-control p-2 mb-3">
									<span class="<?php if(!empty($Price)){echo 'd-block';}else{echo' d-none';} ?>">Price</span>
								</label>
							</div>
                            <div class="col-md-12">
								<label class="label d-block mb-0">
									<input type="number" value="<?php  echo $Discount; ?>" name="discount"  placeholder="Discount" class="form-control p-2 mb-3">
									<span class="<?php if(!empty($Discount)){echo 'd-block';}else{echo' d-none';} ?>">Discount</span>
								</label>
							</div>
							<div class="col-md-12">
								<textarea name="description" id="editor" placeholder="Description" class="form-control p-2 mb-3"><?php echo $description;?></textarea>
							</div>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="card card-body bg-light pb-0 mb-3">
							<h6><i class="fa fa-image pr-2"></i>Select Image</h6>
							<div class="agent-img mb-2 text-center border">
								<img id="blah" src="../images/demo.png" width="100%">
							</div>
							<input type="file" id="imgInp" name="image" class="form-control p-2 mb-3 bg-white">		
						</div>
					</div>
					<div class="col-12 text-right">
						<input type="submit" value="Add Product" name="addpost" class="btn btn-sm btn-primary px-3">
					</div>
				</div>
			</div>
		</div>
	</div>
<form>
 <script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'editor' );



$('.form-control').on('blur', function(){
	var emptycheck = $(this).val();
	if(emptycheck.trim() == '' ){
		$(this).next('span').removeClass('d-inline-block').addClass('d-none');
		$(this).attr("class", "border form-control p-2 mb-3");
		var text =	$(this).next('span').text();
		$(this).attr("placeholder",text);
		
	}else{
		$(this).attr("class", "border form-control p-2 mb-3");
		$(this).next('span').removeClass('text-primary').addClass('d-inline-block span-color');
	}
	
})
.on('focus', function(){
	$(this).attr("placeholder", "");
	$(this).attr("class", "border border-primary form-control p-2 mb-3");
	
	$(this).next('span').removeClass('d-none').addClass('d-inline-block text-primary');
});


//image show 
function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function (e) {
			$('#blah').attr('src', e.target.result);	
		}
		reader.readAsDataURL(input.files[0]);
	}
}

$("#imgInp").change(function(){
	readURL(this);
});

//select only one checkbox
 $('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});

</script>
<?php
	require_once 'include/footer.php';
?>