<?php
	include 'include/head.php';
	
	
	
		if($_SESSION['admin_id']==false){
			include_once 'include/login-box.php';
		}
		else{
			location('dashboard.php');
		}

	include 'include/footer.php';
?>