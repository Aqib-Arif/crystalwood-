<?php
  require_once 'include/head.php';
  session('admin_id');
  if(isset($_POST['add_cat'])){
	$title			= cleanStr($_POST['title']);
	
	$slug =  str_replace(" ", "-", strtolower($title));

	if(empty($title))
		$error[] = "Please type post title == info-circle == danger";
	
	
	if(empty($error)){
		$insert = insert_and_update_data('insert', 'product_cat', array('slug'=>$slug,'title'=> $title),'', 'image', 'images/product_cat', 'png,jpg,jpeg', '800','300');
		if($insert == true){
			$error[] = 'Post added successfully';
		}
	}
}

if(isset($_POST['update_cat'])){
	$title			= cleanStr($_POST['title']);
	
		
	if(empty($title))
		$error[] = "Please type post title == info-circle == danger";
	
	if(empty($error)){
		$update = insert_and_update_data('update', 'product_cat', array('title'=> $title),"id = $categoryId	", 'image', 'images/product_cat', 'png,jpg,jpeg', '800','300');
		if($update == true){
			$error[] = 'Changes saved successfully';
		}
	}
}


?>
<div id="accordion2" class="">
	<div class="row align-items-center pt-3 sale-heading">
		<div class="col-6">
			<div class="d-flex">
				<h5 class="font-dark">Category Management</h5>
			</div>
		</div>
		<div class="col-6 text-right">
			<button class="btn btn-primary px-2 mb-3" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				<i class="fa fa-search"></i>
			</button>
			<button class="btn btn-primary px-2 mb-3" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
				<i class="fa fa-plus"></i>
			</button>
		</div>
		<div class="col-md-12">
			<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
				<div class="card card-body border-0 shadow mb-3">
					<h6 class="font-weight-bold">Search Category</h6>
					<form method="get" action="" enctype="multipart/form-data" class="align-items-end row">
						<div class="col-md-9 mb-md-0 mb-2">
							<input type="text" value="" name="search" class="form-control bg-light">
						</div>
						<div class="col-md-3">
							<input type="submit" value="Search Now" class="btn btn-sm btn-primary btn-block">
						</div>
					</form>
				</div>
			</div>
			<div id="collapsetwo" class="collapse" aria-labelledby="headingtwo" data-parent="#accordion2">
				<div class="card card-body border-0 shadow mb-3">
					<h6 class="font-weight-bold">Add Category</h6>
					<form method="post" action="" enctype="multipart/form-data" class="d-flex justify-conten-center">
						<div class="col-md-8  p-0">	
                            <input type="text" value="" name="title" class="mb-2 d-block  form-control bg-light" placeholder="Add Title" required>
						</div>	
                        <div class="col-md-4  mb-md-0 mb-2">
							<div class="card card-body bg-light pb-0 mb-3 ">
								<h6 class="text-white"><i class="fa fa-image pr-2 text-white"></i>Select Image</h6>
								<div class="agent-img mb-2 w-100 h-100 text-center  ">
									<img id="blah" src="images/demo.png" width="100%">
								</div>
								<input type="file" id="imgInp" name="image" class="  form-control p-2 mb-3 bg-white" required>		
							</div>
                            <div class="text-right">
                                <input type="submit" value="Add Category" name="add_cat" class=" btn  btn-sm btn-primary">
                            </div>
						</div>	
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 px-3 pt-0 pb-3">
        <div class="card card-body border-0 shadow">
            <div class="card-body p-0">
                <div class="table-responsive">
					<?php
						$postQuery = selectQuery("SELECT * FROM  product_cat  order by id desc",[
						'dataPerPage'		=>	'20',
						'searchVariable'	=>	'search='.$searchText.'&',
						'getVariable'		=>	'page',
						'PageUrl'			=>	'categories.php',
						]);

						if($postQuery['status']== true){
							echo '<div class="table d-table mb-0" style="min-width:800px;">
									<div class="d-table-row text-dark">
										<div style="width:500px;" class="d-table-cell bg-light font-weight-bold border-top border-bottom p-2">Category Name</div>
										<div style="width:150px;" class="d-table-cell bg-light text-center font-weight-bold border-top border-bottom p-2">Action</div>
									</div>';
									
							foreach($postQuery['data'] as $sr => $data){
								$categoryId		= $data['id'];
								$Title	    = $data['title'];
								$image 		    = $data['image'];
								
								if(empty($image)){
									$image = 'demo.png';
							}
							echo'<div class="d-table-row text-dark">
								<div style="width:500px;" class="d-table-cell align-middle border-bottom p-2">
									<div class="d-flex align-items-center">
										<div class="user-img border" style="background-image:url(images/product_cat/'.$image.');"></div>
										<div class="pl-2">
											<b>'.$Title.'</b>
											<p class="mb-0 line-1">'.strip_tags(html_entity_decode($postText)).'</p>
										</div>
									</div>
								</div>
							
								<div style="width:150px;" class="d-table-cell text-center border-bottom align-middle p-2">
									<a href="?id='.$categoryId.'" class="d-inline-flex align-items-center" data-toggle="modal" data-target="#exampleModal'.$categoryId.'"><div class="w-100"><i class="fa fa-pencil"></i></div></a>
									<form method="POST" action="" class="d-inline-block py-2">	
										<input type="hidden" name="table[]" value="product_cat">
										<input type="hidden" name="column[]" value="id">
										<input type="hidden" name="file[]" value="images/product_cat/'.$image.'">
										<input type="hidden" name="value[]" value="'.$categoryId.'">
										<button type="submit" name="delete" class="border-0 text-danger d-inline-flex align-items-center p-0 bg-white"><div class="w-100"><i class="fa fa-trash"></i></div></button>
									</form>
								</div>
							</div>
							<div class="modal fade" id="exampleModal'.$categoryId.'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<form method="post" action="" enctype="multipart/form-data" autocomplete="off">
											<div class="modal-header bg-light">
												<h5 class="modal-title" id="exampleModalLabel">'.$Title.'</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body">
											<input type="text" value="'.$Title.'" name="title" class="mb-2 d-block  form-control bg-light" placeholder="Add Title" required>
											<input type="hidden" name="update_id" value="'.$categoryId.'">
											</div>
											<div class="modal-footer bg-light">
												<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
												<button type="button" name="update_cat" class="btn btn-primary">Save changes</button>
											</div>
										</form>
									</div>
								</div>
							</div>';
					      }	
						echo'</div>';
					    }else{
						echo '<div class="alert alert-primary mb-0">No post found in database.</div>';
				 	  }
				   ?>		
                </div>
           </div>
        </div>
    </div>
</div>
<script>
//image show 
function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function (e) {
			$('#blah').attr('src', e.target.result);	
		}
		reader.readAsDataURL(input.files[0]);
	}
}

$("#imgInp").change(function(){
	readURL(this);
});


<?php
    require_once 'include/footer.php';
?>