		</div>
	</li>
<ul>
<div class="mirror menu"><i class="fa fa-close p-3 text-danger fa-2x"></i></div>
<?php echo error_msg($error); ?>
</body>
</html>