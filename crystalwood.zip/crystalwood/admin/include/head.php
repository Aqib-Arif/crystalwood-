<?php
	include 'include/config.php';
	include 'include/functions.php';	
?>
<HTML lang="en">
<HEAD>
<title>Crystalwood</title>
	<meta charset="UTF-8">
	<meta http-equiv="Content-Language" content="en-us" />
	<meta name="language" 				content="en-us" />
	<meta http-equiv="Content-Type" 	content="text/html; charset=UTF-8" />
	<meta name="viewport" 				content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<meta name="classification" 		content="religion content" />
	<meta name="distribution" 			content="Global" />
	<meta name="rating" 				content="General" />
	<meta name="robots" 				content="" />
	<meta name="revisit-after" 			content="" />
	<meta name="creator" 				content="" />
	<meta name="publisher" 				content="" />
	<meta name="description" 			content="" />
	<meta name="keywords" 				content="">
	
	
	<link rel="shortcut icon" href="images/Fav_Icon.svg" type="image/x-icon">
		
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/font-style.css">
	<link rel="stylesheet" type="text/css" href="css/customize.css">

	<script type="text/javascript" src="js/jquery-3.2.1.slim.min.js"></script>
	<script type="text/javascript" src="js/jquery-2.2.0.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/customize.js"></script>

</head>
<body>

<?php
	if($_SESSION['admin_id']!=false){
		include 'include/navbar.php';
		
	}
?>
