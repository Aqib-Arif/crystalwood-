<?php
	require_once 'config.php';
	require_once 'functions.php';
	
	if(isset($_POST['WEBSITE-LOGIN'])){
		$username		= cleanStr($_POST['username']);
		$password		= cleanStr(salt($_POST['password']));
		$query = "SELECT * FROM web_settings where username='$username' AND password = '$password'";
		$res = mysqli_query($connection_database, $query);
		
			if(mysqli_num_rows($res) ==1){
				
				while($row = mysqli_fetch_assoc($res)){
					$admin_id = $row['id'];
					$_SESSION['admin_id'] = $admin_id;
					location('dashboard.php');
				}
			} 
			else{
				$error[] = "Invalid username or password == info-circle == danger"; 
			}
	}
?>
<section class="login h-100 bg-properties">
	<div class="container">
		<div class="row h-100 align-items-center justify-content-center">
			<div class="col-md-8 px-0 mx-3" style="background-color:#EFF2F7;">
				<div class="d-md-flex d-block align-items-center">
					<div class="w-50 d-md-block d-none img text-center py-3">
						<img src="images/login-vector.png" width="200">
					</div>
					<div class="w-50 form bg-white p-3">
						<div class="text-center mb-3"><img src="images/crystalwood_logo.svg" width="180"  class="mb-2"><p class="text-center text-uppercase"><b>Welcome</b></p></div>
						<form method="post" action="" class="text-right" autocomplete="off">
							<label class="label d-block mb-0">
								<input type="text" name="username" required value="<?php echo $username;?>" placeholder="Username" class="mb-3 form-control user" style="padding: .375rem .75rem; font-size: 1rem;">
								<span class="d-none">Username</span>
							</label>
							<label class="label d-block mb-0">
								<input type="password" name="password" required placeholder="Password" class="mb-3 form-control user" style="padding: .375rem .75rem; font-size: 1rem;">
								<span class="d-none">Password</span>
							</label>
							<input type="submit"  name="WEBSITE-LOGIN" class="btn btn-primary px-4" value="Login">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script>
$('.form-control').on('blur', function(){
	var emptycheck = $(this).val();
	if(emptycheck.trim() == '' ){
		$(this).next('span').removeClass('d-inline-block').addClass('d-none');
		$(this).attr("class", "border form-control mb-3");
		var text =	$(this).next('span').text();
		$(this).attr("placeholder",text);
		
	}else{
		$(this).attr("class", "border form-control mb-3");
		$(this).next('span').removeClass('text-primary').addClass('d-inline-block span-color');
	}
	
})
.on('focus', function(){
	$(this).attr("placeholder", "");
	$(this).attr("class", "border border-primary form-control mb-3");
	
	$(this).next('span').removeClass('d-none').addClass('d-inline-block text-primary');
});
</script>

