<?php
session_start();
error_reporting(0);
	//blocking direct access
	if (preg_match("/config.php/",$_SERVER['SCRIPT_FILENAME']))
	{
		die("Access denied");
	}
	
	//check mysqli installed
	if (!function_exists('mysqli_connect')){
		die("mysqli is not installed<br>");
	}
	
		$server			=	'localhost';
		$user 			=	'root';
		$password		=	'';
		$data_base		=	'crystalwood';
		
	
		global  $connection_database;
		$connection_database		=	mysqli_connect($server,$user,$password,$data_base);	

	if ($_SERVER['HTTPS'] == "on") { 
		$http = 'https';
	}else{
		$http = 'http';
	}
	
	$url_domain 				= strtolower($_SERVER['HTTP_HOST']); 
	$url_dir_file 				= strtolower($_SERVER['PHP_SELF']);
	$url_dir_file_var			= strtolower($_SERVER['REQUEST_URI']);
	$url_domain_dir_file_var	= strtolower(''.$http.'://'.$_SERVER['HTTP_HOST'].''.$_SERVER['REQUEST_URI'].'');
	
	$url_file_name 				= end(explode('/', $url_dir_file));//first file name
	
	$domain 				= strtolower("$http://$url_domain/admin");

	$url_domain = "$http://$url_domain/crystalwood";


//utf8 format connection
	mysqli_query($connection, "set character_set_results='utf8'");
	mysqli_set_charset($connection, "utf8");

//time zone
	date_default_timezone_set("Europe/London");
?>