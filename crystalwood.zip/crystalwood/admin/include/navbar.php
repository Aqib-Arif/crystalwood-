
<ul class="header">
	<li class="topbar">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card border-0 mt-3">
						<div class="row pr-3 align-items-center">
							<div class="col-4">
								<button type="button"  class="btn menu pl-3 d-md-none d-inline-block bg-transparent" title="Backup"><i class="fa fa-bars"></i> </button>
							</div>
							<div class="col-8 text-right">
								<div class="user d-inline-flex align-items-center">
									<div class="pr-3">
										<h6 class="font-weight-bold mb-0">Admin</h6>
										<p class="mb-0">Avalible</p>
									</div>
									<div class="image bg-properties text-center font-weight-bold text-white pt-2" style="<?php if(!empty($Image)){echo 'background-image:url(../images/employers/'.$Image.');';}else{ echo 'background-color:'.$short_name['bgcolor'].';'; }?>;"><?php if(empty($Image)){ echo $short_name['letter']; }?></div>
									<div class="">
										<div class="drop text-left bg-white rounded shadow">
											<!-- <a href="profile.php" class="d-block pl-2 py-2 pt-0"><i class="fa fa-user-o mr-2"></i>Profile</a>
											<a href="" class="d-block pl-2 pb-2 pt-0"><i class="fa fa-unlock mr-2"></i>Change Passwod</a> -->
											<a href="logout.php" class="d-block pl-2 bg-light pb-2 py-2"><i class="fa fa-sign-out mr-2"></i>Logout</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</li>
	<li class="navs">
		<div class="w-100 px-3">
			<div class="logo p-3  mb-3 text-center">
				<img src="images/crystalwood_logo.svg" width="180px" class="pt-2">
			</div>
			<div class="links">
				<a href="dashboard.php" class="<?php if($url_file_name == 'dashboard.php'){echo 'active';}?>"><i class="fa fa-home pr-2"></i> Dashboard</a>
				<a href="categories.php" class="<?php if($url_file_name == 'categories.php' or $url_file_name == 'categories.php' or $url_file_name == 'categories.php'){echo 'active';}?>"><i class="fa fa-list-alt pr-2" aria-hidden="true"></i>Categories Management</a>
				<a href="product.php" class="<?php if($url_file_name == 'product.php' or $url_file_name == 'edit-product.php' or $url_file_name == 'add-product.php'){echo 'active';}?>"><i class="fa fa-product-hunt  pr-2" aria-hidden="true"></i>Product Management</a>
				<a href="blogs.php" class="<?php if($url_file_name == 'blogs.php' or $url_file_name == 'edit-post.php' or $url_file_name == 'add-post.php'){echo 'active';}?>"><i class="fa fa-check-square-o  pr-2"></i>Blog Management</a>
				<a href="contact.php" class="<?php if($url_file_name == 'contact.php'){echo 'active';}?>"><i class="fa fa-phone pr-2" aria-hidden="true"></i>Contact Website</a>
				<a href="email.php" class="<?php if($url_file_name == 'email.php'){echo 'active';}?>"><i class="fa fa-envelope pr-2" aria-hidden="true"></i>E-mail Subcribes</a>
			</div>
		</div>
	</li>
	<li class="body">
	<div class="container">
	
	