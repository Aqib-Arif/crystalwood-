<?php 
	require_once 'include/head.php';

	include_once 'include/navbar.php';
	session('admin_id');
?>
<h4>Dashboard</h4>
<div class="row pb-3 cards pt-3">
	<div class="col-lg-3 col-md-6 mb-3">
		<div class="card today p-3 border-0">
			<p class="text-white mb-2 text-uppercase">Total Post</p>
			<h4 class="text-white mb-0">0</h4>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 mb-3">
		<div class="card week p-3 border-0">
			<p class="text-white mb-2 text-uppercase">Total Product</p>
			<h4 class="text-white mb-0">0</h4>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 mb-3">
		<div class="card month p-3 border-0">
			<p class="text-white mb-2">Total Email</p>
			<h4 class="text-white mb-0">0</h4>
		</div>
	</div>
	<div class="col-lg-3 col-md-6">
		<div class="card life-time p-3 border-0">
			<p class="text-white mb-2">Total Contact</p>
			<h4 class="text-white mb-0">0</h4>
		</div>
	</div>
</div>
<?php
	include 'include/footer.php';
?>	