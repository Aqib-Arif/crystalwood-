// input from history clear javescript
$(document).ready(function(){
	$(document).on('show.bs.modal', '.modal', function () {
		$(this).appendTo('body');
	});
	if (window.history.replaceState){
		window.history.replaceState( null, null, window.location.href );
	}

	$('.menu').click(function() {
		$('.navs').toggleClass('show');
		$('.mirror').toggleClass('show');
	});
	$('.user').click(function() {
		$('.drop').toggleClass('show');
	});
	$('.show-contacts').click(function() {
		$('.res-contact').toggleClass('d-none');
	});
	$('.noti').click(function() {
		$('.dropy').toggleClass('d-none');
	});
	
	
	/* dropdown show on top when table responsive */
		
	$('.table-responsive').on('show.bs.dropdown', function () {
			$('.table-responsive').css( "overflow", "inherit" );
	});

	$('.table-responsive').on('hide.bs.dropdown', function () {
			$('.table-responsive').css( "overflow", "auto" );
	})
	
	
});
$(window).on('load',function(){
    var delayMs = 100; // delay in milliseconds

    setTimeout(function(){
        $('#myModal').modal('show');
    }, delayMs);
}); 