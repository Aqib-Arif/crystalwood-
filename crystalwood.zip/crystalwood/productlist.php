<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="py-md-5 py-2">
    <div class="container">
        <div class="row">
           <div class="col-md-6">
                <div class="izooom  full-image">
                    <img src="<?php echo $url_domain;?>/images/bedroom5.jpg" id="mainimg" class="w-100">
                </div>
                <div class="owl-carousel  slider py-2">
                    <div class="item product-thumbnail">
                        <div class="card border-0">
                            <div  class="slide-thumbnails">
                                <img class="mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                            </div>
                        </div>
                    </div>
                    <div class="item product-thumbnail">
                            <div  class="slide-thumbnails">
                                <img class="mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap" >
                            </div>
                    </div>
                    <div class="item product-thumbnail">
                        <div  class="slide-thumbnails">
                            <img class="mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                        </div>
                    </div>
                    <div class="item product-thumbnail">
                        <div  class="slide-thumbnails">
                                <img class="mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
                            </div>
                    </div>
                    <div class="item product-thumbnail">
                        <div  class="slide-thumbnails">
                                <img class="mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
                            </div>
                    </div>
                    <div class="item product-thumbnail">
                            <div  class="slide-thumbnails">
                                <img class="mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
                            </div>
                    </div>
                </div>
                
           </div>
            <div class="col-md-6">
                <div class="col-md-12 border-bottom ">
                    <a href="#0" class="d-md-inline-block  small text-dark ">Home /</a>
                    <a href="#0" class="d-md-inline-block  small text-dark ">Art /</a>
                    <a href="#0" class="d-md-inline-block  small text-dark"> Vestibulum vel maximus</a>
                    <h5 class="mb-4 pt-4">Vestibulum vel maximus</h5>
                    <h6 class="text-danger mb-4">PKR 20,580 <s class="ml-2 text-dark">PKR 25,580</s></h6>
                    <p class="small mb-4">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante.</p>
                    <p class="small mb-1 text-success">In stock 600 Items</p>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <button class="min btn bg-white  border   text-dark">-</button>
                        </div>
                        <input type="text" class="border text-center" name="qty" id="qty" maxlength="12" style="width: 50px;">
                        <div class="input-group-append">
                            <button  class="plus btn border bg-white  text-dark">+</button>  
                        </div>
                        <a href="" class=" cart-btn btn color text-light ml-3">Add to Cart</a>
                        <a href="addtocart" class="btn color text-light ml-3 buynow">Buy Now</a>
                    </div>
                </div>
                <div class="col-md-12 py-4">
                    <p class="mb-3 small"><strong>SKU :</strong> PD0080</p>
                    <h5 class="small"><strong>Share :</strong>
                       <a href=""><i ></i> </a>
                       <a href=""> </a>
                       <a href=""></a>
                    </h5>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="">
    <div class="container mb-4">
       <div class="row">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link  active border-left-0  border-right-0   border-top-0  border-bottom border-success" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">PRODUCT DESCRIPTION</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact</a>
            </li> -->
          </ul>
          <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active border py-5" id="home" role="tabpanel" aria-labelledby="home-tab">
               <div class="container">
                <p>Ideal for small spaces, our new Alib cloth organizer is an essential statement piece for any basic home décor. Be it a bedroom, changing room, or any other space, this modern storage design is extremely functional and impressively modern and keeps your essentials in place and accessible at all times. Sturdy core wood and metal structure provide this cloth organizer strength and durability for longer times. <br><span id="dots">...</span>
                    <span id="more"><strong>Ideal</strong> for small spaces, our new Alib cloth organizer is an essential statement piece for any basic home décor. Be it a bedroom, changing room, or any other space, this modern storage design is extremely functional and impressively modern and keeps your essentials in place and accessible at all times. Sturdy core wood and metal structure provide this cloth organizer strength and durability for longer times. </span></p>
                <div class="text-center">
                    <button onclick="myFunction()" id="myBtn" class="btn btn-success">Read more</button>
                </div>
               </div>
            </div>
            <!-- <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div> -->
          </div>
       </div>
    </div>
</section>
<section class="">
    <div class="container p-0">
          <h5 class="mb-0">Products similar to this item</h5>
          <div class="owl-carousel pakistan py-3">
                  <div class="item">
                      <div class="card border-0">
                          <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                          <p class="small">Hagen Lounge Chair Classic</p>
                      </div>
                  </div>
                  <div class="item">
                      <div class="card border-0">
                          <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
                          <p class="small">Hagen Lounge Chair Classic</p>
                      </div>
                  </div>
                  <div class="item">
                      <div class="card border-0">
                          <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                          <p class="small">Hagen Lounge Chair Classic</p>
                      </div>
                  </div>
                  <div class="item">
                    <div class="card border-0">
                        <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
                        <p class="small">Hagen Lounge Chair Classic</p>
                    </div>
                </div>
           </div>
    </div>
</section>

<?php
 include 'include/footer.php';
?>         
<script>
    $('.slider').owlCarousel({
    loop:false,
    margin:10,
    nav:false,
    dots: false,
	  autoplay:false,
	  autoplayTimeout:2000,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:5
        },
        
    }
  });
</script>
<script>
	$('.pakistan').owlCarousel({
    loop:true,
    margin:40,
    nav:false,
    dots: false,
	autoplay:true,
	autoplayTimeout:2000,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:4
        },
        
    }
  });
  $('.banner').owlCarousel({    
     lazyLoad:true,     
     rtl:false,     
     loop:true,     
     video:true,     
     center:true,     
     autoplay:true,     
     autoplayTimeout:5000,     
     autoplayHoverPause:false,     
     stagePadding: 0,     
     items:3,          
     // slideBy: 1,     
     // animateOut: 'fadeOut',     
     //     animateIn: 'fadeIn',     
     //     slideSpeed: 30000,     //    
      paginationSpeed: 30000,     
      responsive:{        
        0:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,         
        },         
        576:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,           
        },         
        768:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,     
        },         
        992:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,          
        },        
        1200:{             
            items:1,             
            nav:false,             
            margin:0,             
            dots:false,         
        }     
    } 
});
</script>
<script>
	$('.product-thumbnail').click(function(){
      $(this).find('img').attr('src')
      var pic = $(this).find('img').attr('src')
      $('#mainimg').attr('src', pic);
        
	});
</script>
<script>
  $(function(){  
       $('.izooom').izoomify(); 
  });
</script>
<script>

// plus minus function
jQuery(function(){
  var j = jQuery; 
  var addInput = '#qty'; 
  var n = 1;
  //Set default value to n (n = 1)
  j(addInput).val(n);

  //On click add 1 to n
  j('.plus').on('click', function(){
    j(addInput).val(++n);
  })
  j('.min').on('click', function(){
    //If n is bigger or equal to 1 subtract 1 from n
    if (n >= 1) {
      j(addInput).val(--n);
    } else {
      //Otherwise do nothing
    }
  });
});

// Read More button
$('.moreless-button').click(function() {
  $('.moretext').slideToggle();
  if ($('.moreless-button').text() == "Read more") {
    $(this).text("Read less")
  } else {
    $(this).text("Read more")
  }
});
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>