<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="upload py-md-5 py-2">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-6">
				<div class="card border-0 ">
					<div>
					  <img class="card-img-top mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom6.jpg" alt="">
                      <p class="mb-2 ">Maddox Vantage Queen Bed</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
						 <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					  </div>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border " src="<?php echo $url_domain;?>/images/bedroom2.jpg" alt="">
					  <p class="mb-2 ">Sheath Storage Box</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					     <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border " src="<?php echo $url_domain;?>/images/bedroom3.jpg" alt="">
                      <p class="mb-2 ">Pod Storage Box</p>
					  <p class="text">RS 998 <s class="ml-2 ">RS 1,050</s></p>
					  <div class="icons">
					     <a href="productlist" class="justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						 </a>
						 <a href="" class=" justify-content-center text-center">
							<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						 </a>
					 </div>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom4.jpg" alt="" >
					  <p class="mb-2 ">Latch Storage Box</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
						<img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom5.jpg" alt="" >
						<p class="mb-2">Alib Clothes Organizer Rack</p>
						<p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
						<div class="icons ">
							<a href="productlist" class="justify-content-center text-center">
								<img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
							</a>
							<a href="" class=" justify-content-center text-center">
								<img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
							</a>
						</div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom10.jpg" alt="" >
					  <p class="mb-2 ">Maddox Vantage Queen Size</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom7.jpg" alt="" >
					  <p class="mb-2 ">Latch Storage Box</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom8.jpg" alt="" >
					  <p class="mb-2 ">Fringe Frame</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom9.jpg" alt="" >
					  <p class="mb-2 ">Sunburst Hanging Mirror</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom10.jpg" alt="" >
					  <p class="mb-2 ">Verge Mirror</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom11.jpg" alt="" >
					  <p class="mb-2 ">Armor Mirror</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
						 
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom12.jpg" alt="" >
					  <p class="mb-2 ">Fringe Frame</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
						 
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom13.jpg" alt="" >
					  <p class="mb-2 ">Fringe Frame</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
						  
					 </div>
					</div>
				</div>
			</div>
            <div class="col-md-4 col-6">
				<div class="card border-0">
					<div>
					  <img class="card-img-top w-100 mb-md-3 mb-1 border" src="<?php echo $url_domain;?>/images/bedroom15.jpg" alt="" >
					  <p class="mb-2 ">Zinnia Bedside Table</p>
					  <p class="text">RS 35,700 <s class="ml-2 ">RS 3,550</s></p>
					  <div class="icons ">
					      <a href="productlist" class="justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/cart.svg" width="15" alt="">
						  </a>
						  <a href="" class=" justify-content-center text-center">
							 <img src="<?php echo $url_domain;?>/images/eyes.svg" width="15" alt="">
						  </a>
						 
					 </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
 include 'include/footer.php';
?>