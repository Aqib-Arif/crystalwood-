<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="py-5">
	<div class="container  py-5">
		<div class="col-md-6 border  m-auto form bg-white p-3">
            <div class="text-center mb-3">
                <img src="<?php echo $url_domain;?>/images/crystalwood_logo.svg" width="280" class="mb-2">
            </div>
            <form method="post" action="" autocomplete="off">
                <label class="label  font-weight-bold mb-0">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" required value="" placeholder="Username" class="mb-3 form-control">
                <label class="label  font-weight-bold mb-0">Password <span class="text-danger">*</span></label>
                <input type="password" name="password" required placeholder="Password" class="mb-3 form-control">
                <div class="text-right mb-3">
                   <input type="submit"  name="" class="btn btn-primary px-4" value="Login">
                </div>
                <p class="text-center">Not a member? <a href="register.php"  style="text-decoration: none;">Register</a></p>
            </form>
        </div>
	</div>
</section>
<?php
 include 'include/footer.php';
?>