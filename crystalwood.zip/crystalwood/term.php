<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="py-5">
   <div class="container">
        <h4 class="mb-4">Terms of Use</h4>
        <p>When you visit our site or purchase something from us, you accept all the terms and conditions listed here. So, before any further due, take a moment to read these conditions. These terms of service apply to everyone.</p>
        <p>By agreeing to these terms and conditions, you confirm that you are not a minor and are of the age mentioned on our site.</p>
        <p>You also cannot use our product for any illegal purpose. Also, you have never violated any laws in your jurisdiction. You'll be terminated from our services if you violate any terms or conditions.</p>
        <p>We have the right to refuse our services to anyone due to any kind of reason. Your information other than your credit card information can be shared across networks. Credit card information is always encrypted.</p>
        <p>If the information available on this site is inaccurate or thorough, we won’t take the responsibility for that. </p>
        <p>The information provided on this website is for general understanding and not for making your decisions based on this information. If you want to rely on this information, do it at your own risk</p>
        <p>Our team is always there to guide you thoroughly. Before confirming your purchase, kindly reach out to our sales manager. </p>
        <p>Prices of our products can change anytime without notice. We’re not answerable to you or any third party for the change in prices or discontinuance of our services.</p>
        <p>We made all possible efforts to display the colours of our products as they are. But we can’t guarantee that your monitor shows you the same colour. Delivering quality products is always our main aim, but we don’t guarantee that our product's quality, material, and colour meet your expectations.</p>
        <p>We may provide you access to third-party tools, but we are never responsible for what risks these tools can bring. It’s entirely up to you to use them at your own risk.</p>
        <p>We may also introduce new services and products here. These terms and conditions will also apply to them.</p>
        <p>The content on our website contains links to other third-party websites that are not affiliated with us. Please read their policies as well before purchasing anything from them. We’re not responsible for any harm done by those websites.</p>
        <p>In addition to other prohibitions, you are not allowed to use this website’s content for any unlawful purposes. </p>
        <p>If you have any questions regarding terms and conditions, please contact us.</p>
    </div>
</section>
<?php
 include 'include/footer.php';
?>