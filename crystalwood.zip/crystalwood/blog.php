<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="blog py-md-5 py-2">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-6 mb-md-3 mb-1">
                <div class="card border-0">
                    <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                    <p class="mb-0 small">Hagen Lounge Chair Classic</p>
                    <p class="mb-2 small">Jun 20,2022</p>
                    <a href="" class="small">Read More</a>
                </div>
            </div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
                <div class="card border-0">
                    <img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
                    <p class="mb-0 small">Hagen Lounge Chair Classic</p>
                    <p class="mb-2 small">Jun 20,2022</p>
                    <a href="" class="small">Read More</a>
                </div>
            </div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog2.jpg" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
            <div class="col-md-3 col-6 mb-md-3 mb-1">
				<div class="card border-0">
					<img class="card-img-top mb-2" src="<?php echo $url_domain;?>/images/blog3.png" alt="Card image cap">
					<p class="mb-0 small">Hagen Lounge Chair Classic</p>
					<p class="mb-2 small">Jun 20,2022</p>
					<a href="" class="small">Read More</a>
				</div>
			</div>
        </div>
    </div>
</section>
<?php
 include 'include/footer.php';
?>