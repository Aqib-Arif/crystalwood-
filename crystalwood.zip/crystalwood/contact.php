<?php
	include 'include/head.php';
	include 'include/navbar.php';

    
  if(isset($_POST['save'])){
	$name			= $_POST['name'];
    $email			= $_POST['email'];
    $number			= $_POST['number'];
	$message	    = $_POST['message'];	
	
   if(empty($name))
		$error[] = "Please type post name == info-circle == danger";
	
	if(empty($email))
		$error[] = "Please type post email == info-circle == danger";

    if(empty($number))
		$error[] = "Please type post number == info-circle == danger";
     
    if(empty($message))
		$error[] = "Please type post message == info-circle == danger";
	
	if(empty($error)){
		$insert = insert_and_update_data('insert', 'contact', array('name'=> $name,'email'=> $email,'number'=> $number,'message'=> $message));
	}
}
?>
<section class=" mt-4 py-5 bg-light mb-5">
    <div class="col-md-12 py-5 text-center">
        <h1 class="">Contact Us</h1>
    </div> 
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3 border-0 mt-2">
					<div class="d-flex justify-content-between">
						<div class="d-flex flex-row ">
							<img src="<?php echo $url_domain;?>/images/adress.png"  class="" height="55" alt="">
							<div class="">
								<p class="pl-3  mb-0 font-weight-bold">Address</p>
								<a href="" target="_blank" >
								    <p class="mb-2 pl-3 text-dark small">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								</a>
							</div>
						</div>
					</div>
                 </div>
                 <div class="card mb-3  border-0">
					<div class="d-flex justify-content-between">
						<div class="d-flex flex-row ">
							<img src="<?php echo $url_domain;?>/images/phone.png"  class="" height="55" alt="">
							<div class="">
								<p class="pl-3 pt-1 mb-0 font-weight-bold">Phone</p>
								<a href="tel:+923493121428" class="ml-3 text-dark small">+92 349 312 1428</a>
								<p class="pl-3 small">Mon-Sunday 12:00am - 12:00pm</p>
							</div>
						</div>
					</div>
               </div>
               <div class="card mb-2 border-0">
                   <div class="d-flex justify-content-between">
                       <div class="d-flex flex-row ">
                           <img src="<?php echo $url_domain;?>/images/mail.png" height="55"  class="" alt="">
                           <div class="">
                                <p class="pl-3 pt-1 mb-0 font-weight-bold">Mail</p>
                                <a href="" class="ml-3 text-dark">info@crystalwood.com</a>
                                
                           </div>
                       </div>
                   </div>
               </div>
            </div>
            <div class="col-md-6">
                <form action="" method="post">
                  <label for="" class="font-weight-bold">Name <span class="text-danger">*</span></label>
                  <input type="text" class="form-control mb-3" placeholder="Enter Name *" required name="name" id="">
                  <label for="" class="font-weight-bold">Email <span class="text-danger">*</span></label>
                  <input type="email" class="form-control mb-3" name="email" id="" placeholder="Enter Email *" required>
                  <label for="" class="font-weight-bold">Phone No <span class="text-danger">*</span></label>
                  <input type="number" class="form-control mb-3" name="number" id="">
                  <label for="" class="font-weight-bold">Message <span class="text-danger">*</span></label>
                  <textarea name="message" class="form-control mb-3" id="" cols="20" rows="6" placeholder="Enter Message *" required></textarea>
                  <div class="text-right mb-4">
                     <input type="submit" name="save"class="btn btn-primary py-2 px-4 " value="Send Message">
                  </div>
                </form>
            </div>
        </div>
    </div>
</section>
<section class="map py-3">
    <div class="container-fluid">
        <div class="row">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13620.266688938133!2d73.09954125!3d31.412289099999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1660928017958!5m2!1sen!2s" width="1583" height="450" class="border-0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</section>
<?php
 include 'include/footer.php';
?>