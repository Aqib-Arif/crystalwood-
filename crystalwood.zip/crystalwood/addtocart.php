<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>

<section class="cart mt-4 bg-light">
    <div class="col-md-12 py-5 text-center">
        <h1 class="">Cart</h1>
        <a href="">Home /</a>
        <a href="">Cart </a>
    </div> 
</section>
<section class="main">
    <div class="container mb-4">
        <div class="row">
           <div class="col-md-8 mb-md-0 mt-2 mb-5">
            
                <table class="table" style="min-width:730px;">
                    <thead>
                        <tr>
                            <th width="10%"></th>
                            <th width="30%">PRODUCT</th>
                            <th width="10%">PRICE</th>
                            <th width="25%">QUANTITY</th>
                            <th width="10%">SUBTOTAL</th>
                        </tr>
                    </thead>
                    <tbody class="border-bottom border-top-0">
                        <tr>
                            <th width="15%" class="align-middle">
                                <div action="" class="d-flex align-items-center">
                                    <button type="submit" name="" class="btn bg-white text-dark m-0"><i class="fa fa-times" aria-hidden="true"></i></button>
                                    <img class="img-fluid border" width="50" src="https://akira-elementor.axonvip.com/electronics/265-small_default/vestibulum-vel-maximus.jpg">
                                </div>
                            </th>
                            <td width="20%" class="align-middle font-weight-bold">Vestibulum vel maximus</td>
                            <td width="10%" class="align-middle font-weight-bold">$120.00</td>
                            <td width="25%" class="align-middle">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <button class="min btn bg-white  border  text-dark">-</button>
                                    </div>
                                    <input type="text" class="border text-center" name="qty" id="qty" maxlength="12" style="width: 50px;">
                                    <div class="input-group-append">
                                        <button  class="plus btn border bg-white  text-dark">+</button>
                                    </div>
                                </div>
                            </td>
                            <td width="10%" class="align-middle font-weight-bold"> $120.00</td>
                        </tr>
                    </tbody>
                    <!-- <tbody>
                        <tr>
                            <td colspan="5">
                                <div class="alert table-danger rounded-0 h6 text-center">No records found</div>
                            </td>
                        </tr>
                    </tbody> -->
                    <tbody>
                        <tr>
                            <td colspan="5">
                                <div class="d-flex justify-content-between">
                                    <a href="index.php" class="btn color text-light small">CONTINUE SHOPPING</a>
                                    <button type="submit" name="" class="btn color text-light small">Empty Cart</button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4 mt-4 border">
                <h5 class="pt-3 mb-3 font-weight-bold">CART TOTALS</h5>
                <div class="col-md-12  border-bottom  border-top">
                    <div class="d-flex justify-content-between ">
                        <p class="pt-3">1 item</p>
                        <p class="pt-3 ">$120.00</p>
                    </div>
                    <div class="d-flex justify-content-between ">
                        <p class="">Shipping</p>
                        <p class="">$120.00</p>
                    </div>
                </div>
                <div class="col-md-12 border-bottom">
                    <div class="input-group mb-3 mt-3">
                        <input type="text" class="form-control py-2 mr-2" placeholder="" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn color text-light">ADD</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 border-bottom mb-3">
                    <div class="d-flex justify-content-between">
                        <p class="pt-3">Total (tax excl.)</p>
                        <p class="pt-3 ">$120.00</p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Total (tax incl.)</p>
                        <p  class="">$120.00</p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p>Taxes:</p>
                        <p  class="">$0.00</p>
                    </div>
                </div>
                <div class="col-md-12 mb-3">
                    <button class="btn w-100 color text-light">PROCEED TO CHECKOUT</button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
 include 'include/footer.php';
?> 
<script>
    // plus minus function
jQuery(function(){
  var j = jQuery; 
  var addInput = '#qty'; 
  var n = 1;
  //Set default value to n (n = 1)
  j(addInput).val(n);

  //On click add 1 to n
  j('.plus').on('click', function(){
    j(addInput).val(++n);
  })
  j('.min').on('click', function(){
    //If n is bigger or equal to 1 subtract 1 from n
    if (n >= 1) {
      j(addInput).val(--n);
    } else {
      //Otherwise do nothing
    }
  });
});
</script>