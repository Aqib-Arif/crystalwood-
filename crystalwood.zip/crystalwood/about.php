<?php
	include 'include/head.php';
	include 'include/navbar.php';
?>
<section class="py-5">
    <div class="container">
        <h2 class="mb-5">About Us</h2>
        <h5 class="mb-4">The Crystal Advantage</h5>
        <li>A 10-Year Legacy</li>
        <li>Global and local expertise in mega-scale projects</li>
        <li>Implementation of advanced new technologies such as IMOS</li>
        <li class="mb-5">Quality that stands the test of time</li>
        <h5 class="mb-4">CRYSTALWOOD JOURNEY:</h5>
        <p>Crystal wood is an online platform that provides inexpensive and top-notch furniture of all types. We are a one-stop shop for furniture lovers, be it bedroom furniture, dining room furniture, or tv lounge furniture.</p>
        <p>Coming this far is a dream come true. We have been serving people with innovative furniture for five years. There’s something for everyone at our store. We believe in quality, and we bet you won’t find this much range and prices elsewhere.</p> 
    </div>
</section>
<?php
 include 'include/footer.php';
?>